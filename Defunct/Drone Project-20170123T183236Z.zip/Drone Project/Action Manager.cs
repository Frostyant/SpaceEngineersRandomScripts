//Function of Code//
/*
The point of this code is to translate messages received from the Comms Manager
Then Apply the various actions while keeping security

CURRENT FUNCTIONS :
  move to location
  move to relative location (WIPs)
  send orders
  send order to selected IDs to move to set location
  send order to selected IDs to move to relative location (WIPs)

//Standard format using ',' as separator : "orderID,password,orderinfo0,orderinfo1,..."
//example move order : "M,1234,GPS:0:0:0"
*/

/*==#=====#====#=====#=====#=====#=====#=====#====#=====#=====#=====#=====#=====#====#===================*/
//Setup//
//IMPORTANT//
//ENSURE BLOCK NAMES MATCH !
/*==#=====#====#=====#=====#=====#=====#=====#====#=====#=====#=====#=====#=====#====#===================*/

//Block Names//
//Text block with info in it (such as ID and passwords to acces this machine)
public const string INFO_NAME = "info";
//Remote Controle
public const string CNTRL_NAME = "cntrl";
//Comms Manager Programmable block
public const string COMMS_CONTROLLER_NAME = "comms manager";
//Beacon
//public const string BACON_NAME = "bacon";

//orders list//
//Go to GPS
//orderinfo0 = GPS
public const string ORD_MOVE = "M";
//Send order
//orderinfo0 = targetID
//orderinfo1 = orderID
//orderinfo(n) = orderinfo(n-2) of that type ()
//last order info : comms manager password
public const string ORD_SEND = "S";
//Move Target to Waypoint
//orderinfo0 = targetID
//orderinfo1 = GPS location
//orderinfo2 = comms manager password
public const string ORD_MTW = "MTW";
//Move Target here
//orderinfo0 = targetID
//orderinfo1 = comms manager password
public const string ORD_MTH = "MTH";
//Move Targets to relative positions (WIP)
public const string ORD_MTR = "MTR";
//move to relative position (WIP)
public const string ORD_MR = "MR";


//PASSORD//
//this password is more secure than the Comms one BUT it is "hardwired"
//ie you have to change the programming block to edit this
//also dont use the standard one
//really DONT
public const string PASSWORD = "1234";



//Indicators//
//MUST MATCH Comms Manager indicators !
//Indicates this is a send message order
//applied before the "main" argument
public const string SEND_MESSAGE_IND = "Send";

//Indicates the separation between parts of the argument
//for instance if this indicators is ';', then the send message "message" command is : "Send;Receive;message"
//More about Receive later
//it NEEDS to be a single charachter though
public const char ARG_SEP_IND = ' ';

//Indicates that this is just to check for received messages
//For Various Design reasons you NEED to apply the Receive indicator AFTER the Send one
//THis Insures that the PB on the receiving end doesn't confuse this with some other order
public const string REC_MESSAGE_IND = "Receive";

//Indicates the message Separators AND in the info text panel
//Used to separate info in a message
//Usually all messages should be of the form : "SenderID;ReceiverID;orders (;password)" when SENT
//for info it will usually be : "ID (;password)"
//you might not have the password bit hence the ()
//note that Receiver ID can just indicate a GROUP of IDs,
//but that depends on how you have your ID system Setup
public const char MES_SEP_IND = ';';

//Indicates orders Separator
//this is the separator used within the message part above
//Standard format using ',' as separator : "orderID,password,orderinfo0,orderinfo1,..."
//example move order : "M,1234,GPS:0:0:0"
//within full message : "SenderID;ReceiverID;M,1234,GPS:0:0:0;comms password"
public const char ORD_SEP_IND = ',';

//Indicates ID Separator
//used to separate IDs, usefull for Grouping grids together and giving collective orders
public const char ID_SEP_IND = '_';




/*==#=====#====#=====#=====#=====#=====#=====#====#=====#=====#=====#=====#=====#====#===================*/
//dont edit unless you know what you are doing !//
/*==#=====#====#=====#=====#=====#=====#=====#====#=====#=====#=====#=====#=====#====#===================*/

//Methods//

//Extracts "raw" info from text panel
public string GetRaw(IMyTextPanel txt){
  string output;
  output =txt.GetPublicText();
  return output;
}

public string[] GetRef(IMyTextPanel txt,char sep){
	//Divides RAW into an array for later use
	string raw;
	raw=GetRaw(txt);
	string[] output =raw.Split(sep);
	return output;
}

public bool CompareIDs(string ID0,string ID1,char sep){
  //Checks if ID0 contains or is equal to ID1
  //if yes, return true, else returns false

  bool output;

  output = true;

  string[] ID0_full = ID0.Split(sep);
  string[] ID1_full = ID1.Split(sep);

  for(int it = 0; it <= ID0_full.Length; it++){
    if(ID0_full[it] != ID1_full[it]){
      output = false;
      break;
    }
  }

  return output;
}

public void GoTo(IMyRemoteControl cntrl, Vector3 Pos, bool Relative){
  //orders ship to move to Vector location
	Vector3 obj;

	if (Relative == true){
			obj = Pos + cntrl.GetPosition();
	}else{
		obj=Pos;
	}

  cntrl.SetAutoPilotEnabled(true);
	cntrl.AddWaypoint(obj,"obj");
	cntrl.SetAutoPilotEnabled(true);
}

public Vector3 GPStoVector(string gps){

	string[] coords;

	//Getting Target Position//

	coords = gps.Split(':');

	//Pending, need to change indices

	Vector3 gpsvector = new Vector3(Convert.ToSingle(coords[2]),
							 Convert.ToSingle(coords[3]),
							 Convert.ToSingle(coords[4]));

	return gpsvector;
}

public void SendOrder(string[] fullorders){

  IMyProgrammableBlock controller = GridTerminalSystem.GetBlockWithName(
  COMMS_CONTROLLER_NAME) as IMyProgrammableBlock;

  //full order[3] contains the orderID we are sending, then password etc.
  string message = fullorders[3] + ORD_SEP_IND + PASSWORD;

  //this is for special info
  for(int it = 3 ; it <= fullorders.Length-2;it++){
      message = message + ORD_SEP_IND + fullorders[it];
  }


  //prepping message in appropriate format
  //fullorder[2] contains the targetID
  controller.TryRun(
  SEND_MESSAGE_IND + ARG_SEP_IND +
  fullorders[2] + MES_SEP_IND +
   message + MES_SEP_IND +
    fullorders[fullorders.Length-1]);
}

public string VectorToGPS(Vector3 vec){
	string output;

	output = "GPS:location:"
		+ Convert.ToString(vec.X) +	":"
		+ Convert.ToString(vec.Y) + ":"
		+ Convert.ToString(vec.Z) + ":";

	return output;
}



/*==#=====#====#=====#=====#=====#=====#=====#====#=====#=====#=====#=====#=====#====#===================*/
//dont edit unless you know what you are doing !//
/*==#=====#====#=====#=====#=====#=====#=====#====#=====#=====#=====#=====#=====#====#===================*/

void Main(string argument)
{
  //IMyBeacon bacon = GridTerminalSystem.GetBlockWithName(BACON_NAME) as IMyBeacon;
  //getting full message
  string[] fullmessage = argument.Split(MES_SEP_IND);

  //bacon.SetCustomName(fullmessage[0]);
  //getting full orders
  string[] fullorders = fullmessage[1].Split(ORD_SEP_IND);

  //bacon.SetCustomName("0");
  //checking hardwired password
  if(PASSWORD == fullorders[1]){
    //bacon.SetCustomName("1");
    //Now time to chekc for every single possible order//

    //if order is to move
    if(fullorders[0] == ORD_MOVE){
      //bacon.SetCustomName(fullorders[2]);
      //Getting Remote control
      IMyRemoteControl cntrl = GridTerminalSystem.GetBlockWithName(CNTRL_NAME) as IMyRemoteControl;

      //Clearing PAst waypoints

      //get objective vector
      Vector3 ObjectiveVector = GPStoVector(fullorders[2]);
      //move to location
      GoTo(cntrl,ObjectiveVector,false);
    }else{
      //if order is to send order
      if(fullorders[0] == ORD_SEND){
        SendOrder(fullorders);
      }else{
        if(fullorders[0] == ORD_MTH){
          //Getting Remote control
          IMyRemoteControl cntrl = GridTerminalSystem.GetBlockWithName(CNTRL_NAME) as IMyRemoteControl;
          //Getting local position
          Vector3 pos = cntrl.GetPosition();

          //converting to GPS for formatting purposes
          string GPS = VectorToGPS(pos);

          //preping send order
          string sendorders =
          "who cares about this ?" + ORD_SEP_IND + "no one, these are skipped"
          + ORD_SEP_IND + fullorders[2] + ORD_SEP_IND + ORD_MOVE
          + ORD_SEP_IND + GPS + ORD_SEP_IND + fullorders[3];


          //formatting send order for the send function
          string[] sendordersfull = sendorders.Split(ORD_SEP_IND);

          //sending ! (to Comms Manager)
          SendOrder(sendordersfull);
        }else{
          if(fullorders[0] == ORD_MTW){
            //preping send order
            string sendorders =
            "who cares about this ?" + ORD_SEP_IND + "no one, these are skipped"
            + ORD_SEP_IND + fullorders[2] + ORD_SEP_IND + ORD_MOVE
            + ORD_SEP_IND + fullorders[3] + ORD_SEP_IND + fullorders[4];

            //formatting send order for the send function
            string[] sendordersfull = sendorders.Split(ORD_SEP_IND);

            //sending ! (to Comms Manager)
            SendOrder(sendordersfull);

          }else{

          }

        }
      }
    }


  }else{
    //TO DO issue warning
  }






}
