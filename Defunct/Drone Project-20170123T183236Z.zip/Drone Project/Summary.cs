Just A summary of what has been done till now

(D) done
(NS) Not Started
(WIP) Work in Progress

-Building up Comms Manager

  Comms Manager functions :
    -Sending Messages to all Grids (D)
    -Sending Messages to specific Grids (NS)
    -Receiving Messages (WIP)
    -Activating Action Manager (WIP)

-Building up Action Manager

  Action Manager functions :
    -Sending Specific Message to ID (given in argument) (WIP)
    -Sending move orders (WIP)
    -Prforming Move order (WIP)
